USE u937509157_omarb;

UPDATE functionsTbl SET Name = "display_error_message()" WHERE ID=1;
SELECT * FROM functionsTbl WHERE ID=1;
