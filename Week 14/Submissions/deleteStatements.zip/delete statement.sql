USE u937509157_omarb;

DELETE FROM languagesTbl WHERE Language="foo";
SELECT * FROM languagesTbl where Language="foo";
